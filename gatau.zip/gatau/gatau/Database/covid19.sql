-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2020 at 02:24 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid19`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_statik`
--

CREATE TABLE `data_statik` (
  `id` int(11) NOT NULL,
  `id_negara` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `terkonfirmasi` int(11) NOT NULL,
  `aktif` int(11) NOT NULL,
  `sembuh` int(11) NOT NULL,
  `meninggal` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_statik`
--

INSERT INTO `data_statik` (`id`, `id_negara`, `terkonfirmasi`, `aktif`, `sembuh`, `meninggal`, `tanggal`) VALUES
(5, 'JPN', 132, 128, 2, 2, '2020-05-07 23:57:00'),
(6, 'JPN', 134, 129, 2, 3, '2020-05-07 23:58:00'),
(7, 'FR', 442, 400, 38, 4, '2020-05-07 23:59:00'),
(8, 'FR', 448, 406, 38, 4, '2020-05-08 00:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `negara`
--

CREATE TABLE `negara` (
  `id_negara` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_negara` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `negara`
--

INSERT INTO `negara` (`id_negara`, `nama_negara`) VALUES
('FR', 'Francise'),
('JPN', 'Japan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_statik`
--
ALTER TABLE `data_statik`
  ADD PRIMARY KEY (`id`),
  ADD KEY `negara` (`id_negara`);

--
-- Indexes for table `negara`
--
ALTER TABLE `negara`
  ADD PRIMARY KEY (`id_negara`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_statik`
--
ALTER TABLE `data_statik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data_statik`
--
ALTER TABLE `data_statik`
  ADD CONSTRAINT `data_statik_ibfk_1` FOREIGN KEY (`id_negara`) REFERENCES `negara` (`id_negara`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
